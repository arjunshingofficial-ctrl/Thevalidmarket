<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header class="adm-header">
        <div class="adm-container">
            <div class="logo">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
            </div>
            <nav class="adm-navigation">
                <?php wp_nav_menu( array( 'theme_location' => 'primary', 'fallback_cb' => false ) ); ?>
            </nav>
            <div class="adm-header-actions">
                <a href="/cart" class="cart-button">Cart</a>
                <?php if ( is_user_logged_in() ) : ?>
                    <a href="/dashboard" class="account-button">Dashboard</a>
                <?php else : ?>
                    <a href="<?php echo esc_url( wp_login_url() ); ?>" class="account-button">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main class="adm-main-content">
