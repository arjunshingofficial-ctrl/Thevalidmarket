<?php
get_header(); ?>
<div class="adm-hero">
    <h1>Welcome to Asia D Market</h1>
    <p>Your premium marketplace for digital products, VPNs, and proxies.</p>
    <a href="/store" class="adm-btn">Shop Now</a>
</div>
<div class="adm-featured-products">
    <h2>Featured Products</h2>
    <div class="adm-grid">
        <?php
        $products = new WP_Query( array(
            'post_type' => 'adm_product',
            'posts_per_page' => 4,
        ) );
        if ( $products->have_posts() ) :
            while ( $products->have_posts() ) : $products->the_post();
                get_template_part( 'templates/content', 'product-card' );
            endwhile;
            wp_reset_postdata();
        else :
            echo '<p>No products found.</p>';
        endif;
        ?>
    </div>
</div>
<?php get_footer(); ?>
