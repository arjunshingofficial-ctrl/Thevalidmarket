<?php
/**
 * Standalone mock test runner for ADM plugin.
 * Since PHP CLI/PHPUnit is missing locally, we run these assertions
 * in a mock environment to validate the internal logic.
 */

// Mock WordPress functions
function get_post_meta( $id, $key, $single ) {
    global $mock_meta;
    return $mock_meta[$id][$key] ?? '';
}

require_once __DIR__ . '/../includes/class-adm-products.php';

// Test Product Pricing Logic
global $mock_meta;
$mock_meta = [
    1 => [ 'adm_price' => '100', 'adm_discount' => '0' ],
    2 => [ 'adm_price' => '100', 'adm_discount' => '20' ],
    3 => [ 'adm_price' => '100', 'adm_discount' => '150' ], // Invalid discount
    4 => [ 'adm_price' => '-50', 'adm_discount' => '0' ]   // Invalid negative
];

function assertEqual($expected, $actual, $testName) {
    if ($expected === $actual) {
        echo "PASS: $testName\n";
    } else {
        echo "FAIL: $testName - Expected $expected, got $actual\n";
    }
}

// Tests
assertEqual( 100.0, ADM_Products::get_calculated_price(1), "Standard Price" );
assertEqual( 80.0, ADM_Products::get_calculated_price(2), "Discounted Price" );
assertEqual( 100.0, ADM_Products::get_calculated_price(3), "Invalid Discount ignored" );
assertEqual( 0.0, ADM_Products::get_calculated_price(4), "Negative price floored to 0" );

// Test Auth Migrations (Assuming PHP password_hash available)
require_once __DIR__ . '/../includes/class-adm-auth.php';

// Mock wp_set_password
$wp_password_updated = false;
function wp_set_password($pass, $user_id) {
    global $wp_password_updated;
    $wp_password_updated = true;
}

$auth = new ADM_Auth();
$legacy_bcrypt = password_hash("secret123", PASSWORD_BCRYPT);

// Test 1: Wrong password for bcrypt hash
$check1 = $auth->migrate_bcrypt_password(false, "wrongpass", $legacy_bcrypt, 1);
assertEqual(false, $check1, "Auth fails on wrong legacy password");

// Test 2: Correct password for bcrypt hash
$check2 = $auth->migrate_bcrypt_password(false, "secret123", $legacy_bcrypt, 1);
assertEqual(true, $check2, "Auth succeeds on correct legacy password");
assertEqual(true, $wp_password_updated, "wp_set_password called on success");

// Test 3: Redirects
$user_customer = (object) ['roles' => ['adm_customer']];
$user_admin = (object) ['roles' => ['administrator']];

function home_url($path = '') { return "http://site.com" . $path; }
function admin_url() { return "http://site.com/wp-admin"; }

assertEqual("http://site.com/dashboard", $auth->custom_login_redirect("", "", $user_customer), "Customer redirects to dashboard");
assertEqual("http://site.com/wp-admin", $auth->custom_login_redirect("", "", $user_admin), "Admin redirects to wp-admin");

// Mocking WP_REST_Request & Errors for Cart/Orders
class WP_REST_Request {
    private $params = [];
    public function __construct($params) { $this->params = $params; }
    public function get_param($key) { return $this->params[$key] ?? null; }
}
class WP_Error {
    public $code; public $msg;
    public function __construct($code, $msg) { $this->code = $code; $this->msg = $msg; }
}
function get_post_type($id) { return $id ? 'adm_product' : false; }
function get_post_status($id) { return $id == 999 ? 'draft' : 'publish'; }
function rest_ensure_response($res) { return $res; }
function absint($num) { return abs((int)$num); }

require_once __DIR__ . '/../includes/class-adm-cart.php';
$cart = new ADM_Cart();
$req_valid = new WP_REST_Request(['product_id' => 1, 'quantity' => 2]);
$res_valid = $cart->add_to_cart($req_valid);
assertEqual(true, is_array($res_valid) && $res_valid['success'], "Cart Add: Valid product succeeds");
assertEqual(200.0, $res_valid['cart_item']['subtotal'], "Cart Add: Price calculates server-side (100x2)");

$req_invalid = new WP_REST_Request(['product_id' => 999]);
$res_invalid = $cart->add_to_cart($req_invalid);
assertEqual(true, $res_invalid instanceof WP_Error && $res_invalid->code === 'invalid_product', "Cart Add: Fails on draft product");

