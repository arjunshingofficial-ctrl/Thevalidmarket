<?php
class ADM_Cart {
    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'adm/v1', '/cart/add', [
            'methods' => 'POST',
            'callback' => [ $this, 'add_to_cart' ],
            'permission_callback' => '__return_true' // Allowed for guests if they have a session
        ]);
    }

    public function add_to_cart( WP_REST_Request $request ) {
        $product_id = absint( $request->get_param( 'product_id' ) );
        $quantity = absint( $request->get_param( 'quantity' ) ) ?: 1;

        if ( ! $product_id || get_post_type( $product_id ) !== 'adm_product' || get_post_status( $product_id ) !== 'publish' ) {
            return new WP_Error( 'invalid_product', 'Invalid or unavailable product.', [ 'status' => 400 ] );
        }

        // Logic to store cart in DB `adm_sessions` goes here (mocked for this step)
        
        // Fetch authoritative price
        $price = ADM_Products::get_calculated_price( $product_id );

        return rest_ensure_response([
            'success' => true,
            'message' => 'Product added to cart',
            'cart_item' => [
                'product_id' => $product_id,
                'quantity' => $quantity,
                'unit_price' => $price,
                'subtotal' => $price * $quantity
            ]
        ]);
    }
}
