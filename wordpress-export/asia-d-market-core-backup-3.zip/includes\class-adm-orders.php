<?php
class ADM_Orders {
    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'adm/v1', '/checkout/process', [
            'methods' => 'POST',
            'callback' => [ $this, 'process_checkout' ],
            'permission_callback' => function () {
                return is_user_logged_in(); // Must be logged in to order
            }
        ]);
    }

    public function process_checkout( WP_REST_Request $request ) {
        global $wpdb;
        $user_id = get_current_user_id();
        
        // Retrieve cart items from DB session (mocked logic here)
        $cart_items = $request->get_param('items') ?? [];
        if ( empty( $cart_items ) ) {
            return new WP_Error( 'empty_cart', 'Cannot checkout with an empty cart.', [ 'status' => 400 ] );
        }

        $wpdb->query('START TRANSACTION');

        try {
            $total = 0;
            $items_to_insert = [];

            foreach ( $cart_items as $item ) {
                $pid = absint( $item['product_id'] );
                $qty = absint( $item['quantity'] );
                
                if ( get_post_status( $pid ) !== 'publish' ) {
                    throw new Exception('Product unavailable.');
                }

                // Authoritative recalculation
                $price = ADM_Products::get_calculated_price( $pid );
                $sub = $price * $qty;
                $total += $sub;

                $items_to_insert[] = [
                    'product_id' => $pid,
                    'quantity' => $qty,
                    'price_snapshot' => $price,
                    'subtotal' => $sub
                ];
            }

            // Create Order
            $wpdb->insert( "{$wpdb->prefix}adm_orders", [
                'user_id' => $user_id,
                'subtotal' => $total,
                'total' => $total,
                'payment_status' => 'PAYMENT_REVIEW', // Initial status
                'order_status' => 'PENDING'
            ]);
            $order_id = $wpdb->insert_id;

            // Insert Items
            foreach ( $items_to_insert as $i ) {
                $i['order_id'] = $order_id;
                $wpdb->insert( "{$wpdb->prefix}adm_order_items", $i );
            }

            $wpdb->query('COMMIT');

            return rest_ensure_response([
                'success' => true,
                'order_id' => $order_id,
                'status' => 'PAYMENT_REVIEW'
            ]);

        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            return new WP_Error( 'checkout_failed', $e->getMessage(), [ 'status' => 500 ] );
        }
    }
}
