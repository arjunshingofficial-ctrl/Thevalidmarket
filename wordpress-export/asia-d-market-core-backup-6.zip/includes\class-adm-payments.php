<?php
class ADM_Payments {
    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'adm/v1', '/webhooks/crypto', [
            'methods' => 'POST',
            'callback' => [ $this, 'handle_crypto_webhook' ],
            'permission_callback' => '__return_true' // Public, relies on signature validation
        ]);
        
        // Internal REST route for Admins to manually verify UPI/Deposits
        register_rest_route( 'adm/v1', '/payments/verify', [
            'methods' => 'POST',
            'callback' => [ $this, 'admin_manual_verification' ],
            'permission_callback' => function () {
                return current_user_can( 'administrator' );
            }
        ]);
    }

    /**
     * Prevents webhook replay attacks by logging the event ID.
     */
    private static function is_duplicate_event( $provider, $event_id ) {
        global $wpdb;
        $inserted = $wpdb->insert( "{$wpdb->prefix}adm_webhook_events", [
            'provider' => $provider,
            'event_id' => $event_id,
            'status' => 'PROCESSED'
        ]);
        // If insert fails due to UNIQUE constraint, it's a duplicate
        return ( $inserted === false );
    }

    /**
     * Verifies the HMAC signature. (Mocked interface for Crypto provider)
     */
    private static function verify_signature( WP_REST_Request $request ) {
        $signature = $request->get_header( 'X-Crypto-Signature' );
        if ( ! $signature ) return false;
        // In a real implementation: hash_hmac( 'sha256', $request->get_body(), MOCK_SECRET )
        // MOCKED: For this isolated export, we assume the signature matches if provided
        return $signature === 'mock-valid-signature';
    }

    /**
     * Handles incoming crypto payment webhooks safely.
     */
    public function handle_crypto_webhook( WP_REST_Request $request ) {
        global $wpdb;

        if ( ! self::verify_signature( $request ) ) {
            return new WP_Error( 'invalid_signature', 'Unauthorized', [ 'status' => 401 ] );
        }

        $event_id = sanitize_text_field( $request->get_param( 'event_id' ) );
        $payload_type = sanitize_text_field( $request->get_param( 'type' ) );
        $reference_id = sanitize_text_field( $request->get_param( 'reference_id' ) ); // ID of deposit or order

        if ( ! $event_id || ! $payload_type || ! $reference_id ) {
            return new WP_Error( 'bad_request', 'Missing payload data', [ 'status' => 400 ] );
        }

        if ( self::is_duplicate_event( 'crypto', $event_id ) ) {
            // Acknowledge receipt without processing twice (Idempotency)
            return rest_ensure_response( [ 'success' => true, 'message' => 'Duplicate event ignored.' ] );
        }

        if ( $payload_type === 'deposit.paid' ) {
            $result = self::verify_wallet_deposit( $reference_id, 'crypto' );
            if ( is_wp_error( $result ) ) return $result;
        } elseif ( $payload_type === 'order.paid' ) {
            $result = self::verify_order_payment( $reference_id );
            if ( is_wp_error( $result ) ) return $result;
        } else {
            return rest_ensure_response( [ 'success' => true, 'message' => 'Event type ignored.' ] );
        }

        return rest_ensure_response( [ 'success' => true ] );
    }

    /**
     * State Machine: Transitions an Order from PAYMENT_REVIEW to PAID
     */
    public static function verify_order_payment( $order_id ) {
        global $wpdb;
        $order_id = absint( $order_id );

        $wpdb->query( 'START TRANSACTION' );

        $order = $wpdb->get_row( $wpdb->prepare( "SELECT id, payment_status FROM {$wpdb->prefix}adm_orders WHERE id = %d FOR UPDATE", $order_id ) );
        
        if ( ! $order ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'not_found', 'Order not found.', [ 'status' => 404 ] );
        }

        if ( $order->payment_status === 'PAID' ) {
            $wpdb->query( 'ROLLBACK' );
            return true; // Idempotent success
        }

        if ( $order->payment_status !== 'PAYMENT_REVIEW' && $order->payment_status !== 'PENDING' ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'invalid_state', 'Order is in an invalid state for payment.', [ 'status' => 400 ] );
        }

        $wpdb->update( "{$wpdb->prefix}adm_orders", [ 'payment_status' => 'PAID', 'order_status' => 'PROCESSING' ], [ 'id' => $order_id ] );
        
        $wpdb->query( 'COMMIT' );
        return true;
    }

    /**
     * Verifies a pending deposit and atomically credits the wallet.
     */
    public static function verify_wallet_deposit( $deposit_id, $provider ) {
        global $wpdb;
        $deposit_id = absint( $deposit_id );

        $wpdb->query( 'START TRANSACTION' );

        $deposit = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}adm_wallet_deposits WHERE id = %d FOR UPDATE", $deposit_id ) );
        
        if ( ! $deposit ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'not_found', 'Deposit not found.', [ 'status' => 404 ] );
        }

        if ( $deposit->status === 'COMPLETED' ) {
            $wpdb->query( 'ROLLBACK' );
            return true; // Idempotent
        }

        if ( $deposit->status !== 'PENDING' && $deposit->status !== 'PAYMENT_REVIEW' ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'invalid_state', 'Deposit is in an invalid state.', [ 'status' => 400 ] );
        }

        // Lock wallet for update
        $wallet_id = $deposit->wallet_id;
        $wpdb->query( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}adm_wallets WHERE id = %d FOR UPDATE", $wallet_id ) );

        // Update deposit status
        $wpdb->update( "{$wpdb->prefix}adm_wallet_deposits", [ 'status' => 'COMPLETED' ], [ 'id' => $deposit_id ] );

        // Credit the actual wallet ledger (atomic)
        $wpdb->insert( "{$wpdb->prefix}adm_wallet_transactions", [
            'wallet_id' => $wallet_id,
            'type' => 'DEPOSIT',
            'cash_amount' => $deposit->amount_usd,
            'bonus_amount' => $deposit->bonus_amount_usd,
            'idempotency_key' => 'dep_' . $deposit_id, // Prevent duplicate ledger entry
            'reference_type' => 'DEPOSIT',
            'reference_id' => $deposit_id
        ]);

        $wpdb->query( 'COMMIT' );
        return true;
    }

    /**
     * Admin endpoint for manual verification
     */
    public function admin_manual_verification( WP_REST_Request $request ) {
        $type = sanitize_text_field( $request->get_param( 'type' ) ); // 'order' or 'deposit'
        $reference_id = absint( $request->get_param( 'reference_id' ) );
        
        if ( $type === 'deposit' ) {
            $res = self::verify_wallet_deposit( $reference_id, 'manual' );
        } else {
            $res = self::verify_order_payment( $reference_id );
        }

        if ( is_wp_error( $res ) ) return $res;
        return rest_ensure_response( [ 'success' => true ] );
    }
}
